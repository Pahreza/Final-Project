package com.akuma.aplikasibola.client;

import com.akuma.aplikasibola.model.ResponseAllLeague;
import com.akuma.aplikasibola.model.ResponseDetailLeague;
import com.akuma.aplikasibola.model.ResponseLastMatch;
import com.akuma.aplikasibola.model.ResponseLookupTeam;
import com.akuma.aplikasibola.model.ResponseNextMatch;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiInterface {

     @GET("search_all_leagues.php?c=England&s=Soccer")
      Call<ResponseAllLeague> getAllLeague();

     @GET("lookupleague.php")
      Call<ResponseDetailLeague> getDetailLeague(@Query("id") String id);

     @GET("eventsnextleague.php")
      Call<ResponseNextMatch> getNextEventByLeague(@Query("id") String id);

     @GET("eventpastleague.php")
     Call<ResponseLastMatch> getLastEventByLeague(@Query("id") String id);

     @GET("lookupteam.php")
     Call<ResponseLookupTeam> getLookupTeam(@Query("id")String id);

}
